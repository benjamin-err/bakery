package com.example.benjo.backery;

import android.app.Application;

/**
 * Created by benjo on 17.08.2017..
 */

public class BackeryApplication extends Application {

    private static Integer price = 0;

    public static int getPrice() {
        return price;
    }

    public static void setPrice(Integer price) {
        BackeryApplication.price = price;
    }
}
