package com.example.benjo.backery;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MilkshakeActivity extends AppCompatActivity{
    private Integer cijena7;
    private Integer cijena8;
    private Integer cijena9;
    private Integer cijena10;
    private Integer cijena11;
    private Integer cijena12;
    //TextView priceOverview;
    Integer price = BackeryApplication.getPrice();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_milkshake2);


        ImageButton advanceTochoose1 = (ImageButton)findViewById(R.id.imageButton1);

        advanceTochoose1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena7=7;
                price+=cijena7;

                BackeryApplication.setPrice(price);
                //priceOverview.setText(String.valueOf(BackeryApplication.getPrice()));

                Intent i = new Intent(MilkshakeActivity.this,CherryMilkshakeActivity.class);
                startActivity(i);
            }
        });






        ImageButton advanceTochoose2 = (ImageButton) findViewById(R.id.imageButton2);

        advanceTochoose2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena8=8;
                price+=cijena8;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(MilkshakeActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });


        ImageButton advanceTochoose3 = (ImageButton) findViewById(R.id.imageButton3);

        advanceTochoose3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena9=9;
                price+=cijena9;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(MilkshakeActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });

        ImageButton advanceTochoose4 = (ImageButton) findViewById(R.id.imageButton4);

        advanceTochoose4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena10=10;
                price+=cijena10;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(MilkshakeActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });


        ImageButton advanceTochoose5 = (ImageButton) findViewById(R.id.imageButton5);

        advanceTochoose5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena11=11;
                price+=cijena11;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(MilkshakeActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });



        ImageButton advanceTochoose6 = (ImageButton) findViewById(R.id.imageButton6);

        advanceTochoose6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena12=12;
                price+=cijena12;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(MilkshakeActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });

    }
}
