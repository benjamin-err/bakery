package com.example.benjo.backery;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class CupcakesActivity extends AppCompatActivity {


    private Integer cijena1;
    private Integer cijena2;
    private Integer cijena3;
    private Integer cijena4;
    private Integer cijena5;
    private Integer cijena6;
    Integer price = BackeryApplication.getPrice();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cupcakes2);




        ImageButton advanceTochoose7 = (ImageButton) findViewById(R.id.imageButton7);

        advanceTochoose7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena1=1;
                price+=cijena1;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(CupcakesActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);

            }
        });

        ImageButton advanceTochoose8 = (ImageButton) findViewById(R.id.imageButton8);

        advanceTochoose8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena2=2;
                price+=cijena2;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(CupcakesActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });


        ImageButton advanceTochoose9 = (ImageButton) findViewById(R.id.imageButton9);

        advanceTochoose9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena3=3;
                price+=cijena3;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(CupcakesActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });


        ImageButton advanceTochoose10 = (ImageButton) findViewById(R.id.imageButton10);

        advanceTochoose10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena4=4;
                price+=cijena4;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(CupcakesActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });


        ImageButton advanceTochoose11 = (ImageButton) findViewById(R.id.imageButton11);

        advanceTochoose11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena5=5;
                price+=cijena5;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(CupcakesActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });


        ImageButton advanceTochoose12 = (ImageButton) findViewById(R.id.imageButton12);

        advanceTochoose12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cijena6=6;
                price+=cijena6;

                BackeryApplication.setPrice(price);
                Intent i = new Intent(CupcakesActivity.this,CherryMilkshakeActivity.class);

                startActivity(i);
            }
        });

    }
}
