package com.example.benjo.backery;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class CherryMilkshakeActivity extends AppCompatActivity {
    Integer price = BackeryApplication.getPrice();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cherry_milkshake);

        TextView t1=(TextView) findViewById(R.id.textView2);
        String total_price = Integer.toString(price);
        t1.setText(total_price);



        Button advanceTochoose100 = (Button)findViewById(R.id.Button6666666);

        advanceTochoose100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                price = 0;

                BackeryApplication.setPrice(price);
                //priceOverview.setText(String.valueOf(BackeryApplication.getPrice()));

                Intent i = new Intent(CherryMilkshakeActivity.this,MainActivity.class);
                startActivity(i);
            }
        });


    }
    public void open(View view){


        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.paypal.com/signin?country.x=BA&locale.x=en_BA"));
        startActivity(browserIntent);

    }
}

